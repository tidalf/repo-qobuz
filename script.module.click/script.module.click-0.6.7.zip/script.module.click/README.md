script.module.click
======================

Python click library packed for KODI.

Flask dependencies

## Documentation Kodi/Qobuz
Some useful links while developing **Qobuz** *add-on* on **Kodi**

#### GitHub
- [src code](https://github.com/tidalf/plugin.audio.qobuz)

#### Qobuz
- [api endpoints](https://github.com/Qobuz/api-documentation/tree/master/endpoints)

#### Kodi
- [python](http://mirrors.kodi.tv/docs/python-docs)
- [InfoLabels](http://kodi.wiki/view/InfoLabels)

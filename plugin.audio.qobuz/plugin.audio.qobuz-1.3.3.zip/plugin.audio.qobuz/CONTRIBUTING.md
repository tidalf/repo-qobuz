# Contributing to plugin.audio.qobuz

## I want to report a problem or ask a question

Submit an issue here : https://github.com/tidalf/plugin.audio.qobuz/issues

## I want to propose a fix or a new feature

Do a pull request

## I want to break free 

Ok.

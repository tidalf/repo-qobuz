class Addon(object):
    def getAddonInfo(self, *a, **ka):
        pass

    def getSetting(self, *a, **ka):
        pass

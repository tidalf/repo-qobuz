def translatePath(self, *a, **ka):
    return ''


def log(self, *a, **ka):
    return ''


def sleep(self, *a, **ka):
    return ''


def executebuiltin(*a, **ka):
    pass


def executeJSONRPC(*a, **ka):
    pass


def getGlobalIdleTime(*a, **ka):
    pass


class Player(object):
    def play(self, *a, **ka):
        pass


class Monitor(object):
    pass


class Keyboard(object):
    def setHeading(self, *a, **ka):
        pass

    def doModal(self, *a, **ka):
        pass

    def isConfirmed(self, *a, **ka):
        pass

    def getText(self, *a, **ka):
        pass


LOGDEBUG = 1
LOGNOTICE = 2
LOGERROR = 3
LOGSEVERE = 4
LOGWARNING = 5

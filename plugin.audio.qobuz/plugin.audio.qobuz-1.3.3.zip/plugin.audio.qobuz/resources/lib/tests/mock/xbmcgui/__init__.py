class WindowDialog(object):
    def onClick(self, *a, **ka):
        pass

    def onAction(self, *a, **ka):
        pass

    def onFocus(self, *a, **ka):
        pass


class Window(object):
    def setProperty(self, *a, **ka):
        pass


class ControlImage(object):
    pass


class Dialog(object):
    def select(self, *a, **ka):
        pass

    def ok(self, *a, **ka):
        pass

    def yesno(self, *a, **ka):
        pass


class DialogProgressBG(object):
    def create(self, *a, **ka):
        pass

    def update(self, *a, **ka):
        pass

    def close(self, *a, **ka):
        pass


class ListItem(object):
    def setPath(self, *a, **ka):
        pass

    def setInfo(self, *a, **ka):
        pass

    def addContextMenuItems(self, *a, **ka):
        pass

    def setArt(self, *a, **ka):
        pass

    def setProperty(self, *a, **ka):
        pass

    def setIconImage(self, *a, **ka):
        pass

    def setThumbnailImage(self, *a, **ka):
        pass

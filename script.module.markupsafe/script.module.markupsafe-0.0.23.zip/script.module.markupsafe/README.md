script.module.markupsafe
======================

Python markupsafe library packed for KODI.

Flask dependencies
# script.module.markupsafe

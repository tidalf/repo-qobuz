script.module.jinja2
======================

Python jinja2 library packed for KODI.

Flask dependencies
# script.module.jinja2

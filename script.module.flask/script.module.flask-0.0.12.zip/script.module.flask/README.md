script.module.flask
======================

Python Flask library packed for KODI.

A microframework based on Werkzeug, Jinja2 and good intentions http://flask.pocoo.org/
# script.module.flask

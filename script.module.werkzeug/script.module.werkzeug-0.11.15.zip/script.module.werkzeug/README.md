script.module.werkzeug
======================

Python werkzeug library packed for KODI.

flask dependencies
# script.module.werkzeug

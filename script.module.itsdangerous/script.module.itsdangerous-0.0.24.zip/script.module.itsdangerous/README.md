script.module.itsdangerous
======================

Python itsdangerous library packed for KODI.

flask dependencies
# script.module.itsdangerous
